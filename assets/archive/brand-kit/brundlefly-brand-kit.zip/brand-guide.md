# Brundlefly brand rules

## Name and text

Brand name: Brundlefly.
Wordmark: BRUNDLEFLY.
Use the supplied banner as the canonical raster wordmark treatment.
The wordmark uses heavy, tall condensed cream letters with restrained distressed erosion.
No font file is supplied.
Do not regenerate its lettering for each new asset.

The wordmark is the only approved promotional text in this kit.
Confirm new slogans, public persona copy, or decorative text with Harlan.

## Character

Canonical anatomy: the approved six-limbed full-body design.
Four arms: two long shoulder arms and two smaller arms emerging below the ribs.
Two long legs support the body.
Two unequal developing wings attach behind the upper torso.
Mouthparts and bristles are separate from the six body limbs.

Maintain a hunched adult silhouette, uneven limb development, and warped human proportions.
Keep folded rusty flesh, emerging dark chitin, and sparse bristles.
Eyes remain narrow and blue-black with small cold teal reflections.
Hands retain human structure while becoming hooked claws.
Unequal flesh and chitin coverage make the mutation visible.

Avoid orange eyes, cute round proportions, extra limbs, giant butterfly wings, and clothing.
Avoid blood spray and exposed organs.
The horror comes from anatomy and texture.

## Pixel treatment

Use crisp square pixel clusters and hard edges.
Use nearest-neighbor resizing for raster exports.
Simplify details for small applications.
Keep the silhouette and eye sockets clear before adding fine wrinkles.

## Palette

These are fixed design tokens for future layouts.
Raster artwork includes shaded variations around them.

| Role | Hex |
| --- | --- |
| Background | #080B08 |
| Wordmark cream | #E8D4A6 |
| Flesh rust | #AA604B |
| Bruised flesh | #69404B |
| Chitin | #343C3B |
| Eye reflection | #418B90 |
| Wing membrane | #A4B5A0 |
| Edge texture olive | #777648 |

Cream and rust carry the brand.
Teal highlights are sparse.
Keep olive biological textures at outer edges.
Preserve clean dark space around the wordmark and face.

## GitHub usage

Use github-avatar-v2.png as the avatar.
Use the face crop rather than the full body at small sizes.
Keep central facial features inside circular crops.

Use github-banner-v2.png inside the repository README.
Use github-social-preview-v2.jpg in repository Social preview settings.
Both banner exports share the same composition.
Use character-sheet.png for reference when making future poses.

## Asset authority

1. Approved full-body character controls anatomy and mutation stage.
2. Character sheet controls view and detail guidance.
3. Simplified avatar controls small-size rendering.
4. Banner controls wordmark and composition.

If a generated view conflicts with the anatomy reference, follow the anatomy reference.
